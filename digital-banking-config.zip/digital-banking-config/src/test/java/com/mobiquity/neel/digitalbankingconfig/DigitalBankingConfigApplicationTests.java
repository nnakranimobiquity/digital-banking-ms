package com.mobiquity.neel.digitalbankingconfig;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DigitalBankingConfigApplicationTests {

	@Test
	void contextLoads() {
	}

}
